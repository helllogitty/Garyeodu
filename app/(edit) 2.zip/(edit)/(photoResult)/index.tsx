import { ThemedText } from "@/components/ThemedText";
import CustomView from "@/components/ui/CustomView";
import StyledBtn from "@/components/ui/StyledBtn";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import { 
  ActivityIndicator, 
  Dimensions, 
  Image, 
  Alert,
  Pressable 
} from "react-native";
import { BlurView } from 'expo-blur';
import * as S from "./style";

interface DetectedArea {
  x: number;
  y: number;
  width: number;
  height: number;
  type: string;
}

const Result = () => {
  const router = useRouter();
  const { imageUri, detectedAreas } = useLocalSearchParams<{ 
    imageUri: string;
    detectedAreas: string;
  }>();
  
  const screenWidth = Dimensions.get('window').width;
  
  const [currentImageDimensions, setCurrentImageDimensions] = useState({ width: 0, height: 0 });
  const [originalDimensions, setOriginalDimensions] = useState({ width: 0, height: 0 });
  const [parsedDetectedAreas, setParsedDetectedAreas] = useState<DetectedArea[]>([]);
  const [showingBefore, setShowingBefore] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (imageUri && detectedAreas) {
      console.log('📸 받은 params:', {
        imageUri: imageUri ? '✅' : '❌',
        detectedAreas: detectedAreas?.length || 0
      });

      // detectedAreas JSON 파싱
      try {
        const areas = JSON.parse(detectedAreas);
        console.log('🎯 파싱된 areas:', areas);
        setParsedDetectedAreas(areas);
      } catch (error) {
        console.error('❌ detectedAreas 파싱 실패:', error);
        setParsedDetectedAreas([]);
      }

      // 이미지 크기 계산
      calculateImageDimensions(imageUri);
    } else {
      console.error('❌ 필수 params 누락:', { imageUri, detectedAreas });
      setIsLoading(false);
    }
  }, [imageUri, detectedAreas]);

  const calculateImageDimensions = (uri: string) => {
    Image.getSize(uri, (width, height) => {
      console.log('📐 원본 이미지 크기:', { width, height });
      setOriginalDimensions({ width, height });

      const maxWidth = screenWidth * 0.8;
      const maxHeight = 400;
      const ratio = width / height;
      
      let newWidth = maxWidth;
      let newHeight = maxWidth / ratio;
      
      if (newHeight > maxHeight) {
        newHeight = maxHeight;
        newWidth = maxHeight * ratio;
      }
      
      setCurrentImageDimensions({ width: newWidth, height: newHeight });
      console.log('📐 화면 이미지 크기:', { width: newWidth, height: newHeight });
      setIsLoading(false);
    }, (error) => {
      console.error('❌ 이미지 크기 가져오기 실패:', error);
      setIsLoading(false);
    });
  };

  // 좌표를 현재 화면 크기에 맞게 변환
  const scaleCoordinates = (area: DetectedArea) => {
    if (currentImageDimensions.width === 0 || originalDimensions.width === 0) {
      return area;
    }
    
    // 값 검증 및 기본값 설정
    const safeArea = {
      x: isNaN(Number(area.x)) ? 0 : Number(area.x),
      y: isNaN(Number(area.y)) ? 0 : Number(area.y),
      width: isNaN(Number(area.width)) || Number(area.width) <= 0 ? 50 : Number(area.width),
      height: isNaN(Number(area.height)) || Number(area.height) <= 0 ? 50 : Number(area.height),
    };
    
    const scaleX = currentImageDimensions.width / originalDimensions.width;
    const scaleY = currentImageDimensions.height / originalDimensions.height;

    // 스케일 값도 검증
    const safeScaleX = isNaN(scaleX) || !isFinite(scaleX) ? 1 : scaleX;
    const safeScaleY = isNaN(scaleY) || !isFinite(scaleY) ? 1 : scaleY;

    const scaled = {
      x: safeArea.x * safeScaleX,
      y: safeArea.y * safeScaleY,
      width: safeArea.width * safeScaleX,
      height: safeArea.height * safeScaleY,
    };

    return scaled;
  };

  const handleNewEdit = () => {
    router.dismissAll();
    router.replace("/(edit)");
  };

  const handleGoHome = () => {
    router.dismissAll();
    router.replace("/(main)");
  };

  if (isLoading) {
    return (
      <CustomView title="편집 결과" onPressLeftIcon={() => router.back()}>
        <S.Container>
          <S.CenterContainer>
            <ActivityIndicator size="large" color="#007AFF" />
            <ThemedText type="bodyNormal" style={{ marginTop: 10 }}>
              결과를 불러오는 중...
            </ThemedText>
          </S.CenterContainer>
        </S.Container>
      </CustomView>
    );
  }

  if (!imageUri) {
    return (
      <CustomView title="편집 결과" onPressLeftIcon={() => router.back()}>
        <S.Container>
          <S.CenterContainer>
            <ThemedText type="bodyNormal">이미지 데이터를 찾을 수 없습니다</ThemedText>
            <StyledBtn
              label="처음으로"
              onPress={handleNewEdit}
              isActive={true}
              style={{ marginTop: 20 }}
            />
          </S.CenterContainer>
        </S.Container>
      </CustomView>
    );
  }

  return (
    <CustomView title="편집 결과" onPressLeftIcon={() => router.back()}>
      <S.Container>
        <S.TitleSection>
          {parsedDetectedAreas.length > 0 ? (
            <>
              <ThemedText
                type="HeadingSmall"
                style={{ textAlign: "center", marginBottom: 10, color: "#34C759" }}
              >
                편집 완료! 🎉
              </ThemedText>
              <ThemedText
                type="bodyNormal"
                style={{ textAlign: "center", color: "#666" }}
              >
                {parsedDetectedAreas.length}개의 민감정보가 블러 처리되었습니다
              </ThemedText>
            </>
          ) : (
            <>
              <ThemedText
                type="HeadingSmall"
                style={{ textAlign: "center", marginBottom: 10, color: "#34C759" }}
              >
                안전한 이미지입니다! ✅
              </ThemedText>
              <ThemedText
                type="bodyNormal"
                style={{ textAlign: "center", color: "#666" }}
              >
                민감정보가 감지되지 않았습니다
              </ThemedText>
            </>
          )}
        </S.TitleSection>

        <S.ImageSection>
          {imageUri && currentImageDimensions.width > 0 && (
            <S.ImageWrapper>
              <Image
                source={{ uri: imageUri }}
                style={{
                  width: currentImageDimensions.width,
                  height: currentImageDimensions.height,
                }}
                resizeMode="contain"
              />

              {/* 디버깅 정보 */}
              <S.DebugInfo>
                <ThemedText type="bodySmall1" style={{ color: '#999', fontSize: 10 }}>
                  Areas: {parsedDetectedAreas.length}개 | 
                  원본: {originalDimensions.width}x{originalDimensions.height} |
                  현재: {currentImageDimensions.width.toFixed(0)}x{currentImageDimensions.height.toFixed(0)}
                </ThemedText>
              </S.DebugInfo>

              {/* 감지된 영역에 원형 표시 */}
              {parsedDetectedAreas.map((area, index) => {
                const scaledArea = scaleCoordinates(area);
                
                // 중심점 계산 시 안전 처리
                const centerX = scaledArea.x + (scaledArea.width / 2);
                const centerY = scaledArea.y + (scaledArea.height / 2);
                
                // radius 계산 시 안전 처리
                const radius = Math.max(
                  isNaN(scaledArea.width) ? 30 : scaledArea.width,
                  isNaN(scaledArea.height) ? 30 : scaledArea.height
                ) / 2 + 15;

                // 최종 값들 검증
                const safeCenterX = isNaN(centerX) || !isFinite(centerX) ? 50 : centerX;
                const safeCenterY = isNaN(centerY) || !isFinite(centerY) ? 50 : centerY;
                const safeRadius = isNaN(radius) || !isFinite(radius) || radius <= 0 ? 30 : radius;

                const position = {
                  left: safeCenterX - safeRadius,
                  top: safeCenterY - safeRadius,
                  width: safeRadius * 2,
                  height: safeRadius * 2
                };

                console.log(`🎯 원형 ${index}:`, {
                  area,
                  scaledArea,
                  center: { x: safeCenterX, y: safeCenterY },
                  radius: safeRadius,
                  position
                });

                // 위치가 이미지 영역을 벗어나면 표시하지 않음
                if (position.left < -safeRadius || 
                    position.top < -safeRadius || 
                    position.left > currentImageDimensions.width + safeRadius ||
                    position.top > currentImageDimensions.height + safeRadius) {
                  console.log(`⚠️ 원형 ${index} 영역 밖: 표시하지 않음`);
                  return null;
                }

                return showingBefore ? (
                  <S.DetectionCircle key={index} style={position} />
                ) : (
                  <BlurView
                    key={index}
                    intensity={100}
                    tint="light"
                    style={{
                      position: 'absolute',
                      left: position.left,
                      top: position.top,
                      width: position.width,
                      height: position.height,
                      borderRadius: safeRadius,
                      overflow: 'hidden',
                    }}
                  />
                );
              })}

              {/* BEFORE/AFTER 라벨 */}
              {parsedDetectedAreas.length > 0 && (
                <S.ComparisonOverlay>
                  <S.ComparisonLabel showing={showingBefore}>
                    <ThemedText 
                      type="bodySmall1" 
                      style={{ 
                        color: '#fff', 
                        fontWeight: 'bold'
                      }}
                    >
                      {showingBefore ? 'BEFORE' : 'AFTER'}
                    </ThemedText>
                  </S.ComparisonLabel>
                </S.ComparisonOverlay>
              )}
            </S.ImageWrapper>
          )}
        </S.ImageSection>

        <S.BottomSection>
          

          {/* 원본 보기 버튼 */}
          {parsedDetectedAreas.length > 0 && (
            <S.ActionButtonsContainer>
              <Pressable
                onPressIn={() => setShowingBefore(true)}
                onPressOut={() => setShowingBefore(false)}
                style={({ pressed }) => [
                  {
                    backgroundColor: pressed ? '#6C757D' : '#95a5a6',
                    padding: 15,
                    borderRadius: 8,
                    alignItems: 'center',
                    flex: 1,
                  }
                ]}
              >
                <ThemedText 
                  type="bodyMedium" 
                  style={{ 
                    color: '#fff', 
                    fontWeight: 'bold'
                  }}
                >
                  {showingBefore ? '원본 보는 중' : '원본 보기'}
                </ThemedText>
              </Pressable>
            </S.ActionButtonsContainer>
          )}

          <S.ButtonContainer>
            <StyledBtn
              label="새 편집 시작"
              onPress={handleNewEdit}
              isActive={true}
              style={{ backgroundColor: '#6C757D', marginBottom: 10 }}
            />
            <StyledBtn
              label="홈으로"
              onPress={handleGoHome}
              isActive={true}
              style={{ backgroundColor: '#34C759' }}
            />
          </S.ButtonContainer>
        </S.BottomSection>
      </S.Container>
    </CustomView>
  );
};

export default Result;
